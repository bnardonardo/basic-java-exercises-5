package pessoa;

public class Tecnico extends Pessoa{
    public String setor;
    public String funcao;
    
    public Tecnico (String nome,int altura, int diaN, int mesN, int anoN, int idade, String setor, String funcao){
        super(nome, altura, diaN, mesN, anoN, idade);
        this.setor=setor;
        this.funcao=funcao;
    }
    
    public String getSetor(){
        return setor;
    }
    
    public String getFuncao(){
        return funcao;
    }
    
    public void setSetor(){
        this.setor=setor;
    }
    
    public void setFuncao(){
        this.funcao=funcao;
    }
    @Override
    public String toString (){
        return String.format ("Classe herdada: %s, setor: %s, função: %s.", super.toString(), setor, funcao);
    }
}
