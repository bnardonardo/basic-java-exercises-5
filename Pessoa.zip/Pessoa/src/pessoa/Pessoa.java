package pessoa;
import java.util.Date;

public class Pessoa {
    public String nome; 
    public int altura;
    public int idade;
    public int diaN;
    public int mesN;
    public int anoN;

    public Pessoa(String nome, int altura, int diaN, int mesN, int anoN, int idade){
        this.nome=nome;
        this.altura=altura;
        this.diaN=diaN;
        this.mesN=mesN;
        this.anoN=anoN;
        this.idade=idade;
    }
    
    public Pessoa (){
        
    }
    
    public Pessoa (String nome){
        
    }
    public String getNome(){
        return nome;
}
    
    public int getAltura(){
        return altura;
    }
    
    public int getDiaN(){
        return diaN;
    }
    
    public int getMesN(){
        return mesN;
    }
    
    public int getAnoN(){
        return anoN;
    }
    
    public int getIdade(){
        return idade;
    }
    
    public void setNome(){
        this.nome=nome;
    }
    
    public void setAltura(){
        this.altura=altura;
    }
    
    public void setDiaN(){
        this.diaN=diaN;
    }
    
    public void setMesN(){
        this.mesN=mesN;
    }
    
    public void setAnoN(){
        this.anoN=anoN;
    }
    
    public void setIdade(){
        this.idade=idade;
    }
     
   @Override
     public String toString(){
       return String.format ("%s mede %d cm e tem %d anos.", nome, altura, idade);
      
   }
}
