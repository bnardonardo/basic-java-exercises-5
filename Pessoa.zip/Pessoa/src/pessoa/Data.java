package pessoa;
import java.util.GregorianCalendar;
import java.util.Calendar;

public class Data {
    private int dia;
    private int mes;
    private int ano;
    public int i;
    public int cont;
    
    public Data (){
        dia=0;
        mes=0;
        ano=0;
    }
    
    public Data (int dia, int mes, int ano){
        setDia(dia);
        setMes(mes);
        setAno(ano);
    }
    
    public void setDia(int dia){
        if (dia <= 0) this.dia=1;
        else this.dia=dia;
    }
    
    public void setMes (int mes){
        if (mes <= 0) this.mes=1;
        else this.mes=mes;
    }
    
    public void setAno (int ano){
        if (ano<= 0) this.ano=1;
        else this.ano=ano;
    }
    
    public int getDia(){
        return dia;
    }
    
    public int getMes(){
        return mes;
    }
    
    public int getAno(){
        return ano;
    }
    
    public Data (int i, int cont){
        this.i=i;
        this.cont=cont;
    }
    
    public int DiasPassados(){
        cont = getMes()-1;
        if (cont > 1){
            i=i+31;
            if (cont > 2){
                i=i+28;
                if (cont > 3){
                    i=i+31;
                    if (cont > 4){
                        i=i+30;
                        if (cont >= 5){
                            i = i+ 31;
                            if (cont >= 6){
                                i=i+30;
                            }
                            else{
                                i=i+getDia();
                            }
                        }
                    }
                }
            }
        }
        /*i=(getMes()*31);
        i=i+getDia();*/
        return i;
    }
    @Override 
    public String toString(){
        return String.format ("Hoje é: %d/%d/%d.\n E já se passaram %d dias desde o início do ano.", getDia(), getMes(), getAno(), DiasPassados());       
    }
}
