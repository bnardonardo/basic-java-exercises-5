package heranca;
//B é uma subclasse de A
public class B extends A{
    public int b;
    
    public B (int a, int b){
      super(a);
        this.b=b;
    }
    
    public int soma(){
        return b + super.getA();
    }
    
    @Override
    public String toString(){
        return String.format("%s b = %d\n", super.toString(), b);
    }
}
