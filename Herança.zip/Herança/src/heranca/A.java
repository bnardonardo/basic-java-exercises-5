package heranca;
//A é uma superclasse de B
public class A {
    private int a;
    
    public A(int a){
        a=getA();
    }
    
    public int getA(){
        return a;
    }
    
    public void setA(int a){
        this.a=a;
    }
    
    
    public String toString(){
        return String.format ("a = %d,", a);
    }
}
