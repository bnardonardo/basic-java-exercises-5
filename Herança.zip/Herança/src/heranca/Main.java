package heranca;

public class Main {
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");

        B obj=new B(4, 5);
        A o2=new A(3);
       
       obj.setA(1);
        obj.b = 2;
        
        System.out.print(obj);
        obj.soma();
    }
    
}
